#!/usr/bin/env bash

export PATH="${HOME}/miniconda3/bin:${PATH}"

bash
