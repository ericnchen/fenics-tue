About
=====

The C, C++, and fortran files in this directory are used to test the
installation, and are copied from the HDF5 library. The copyright and license
for these files is contained in the TEST_FILES_LICENSE.md file.
