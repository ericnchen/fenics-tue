#!/usr/bin/env bash
#
# Download Miniconda.

wget "https://repo.continuum.io/miniconda/Miniconda3-4.3.21-Linux-x86_64.sh"
