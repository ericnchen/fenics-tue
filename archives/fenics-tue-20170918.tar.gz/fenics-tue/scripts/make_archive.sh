#!/usr/bin/env bash
#
# Download and create a tarball of this code, including the required submodule files.

tar -czvf fenics-tue.tar.gz "$(pwd)/../../fenics-tue/" --exclude=".*"
